# PDF RAG 練習

這份教材會帶你完成一個簡單的 PDF RAG 流程：先讀取 PDF、切割文字並建立向量索引，再用問題找出相關段落，最後組合成可交給語言模型的 prompt。

主要練習檔案是 `pdf_loader_student.ipynb`。請使用 VS Code 開啟整個專案資料夾，並按照 notebook 的順序執行。

## 教材內容

```text
rag_course_student/
├── README.md
├── pdf_loader_student.ipynb
├── rag_course_presentation.html
├── pyproject.toml
├── uv.lock
├── .python-version
├── data/
│   └── pdf/
│       └── 課程使用的 PDF 文件
└── src/
    └── rag_langchain_main/
        └── __init__.py
```

- `pdf_loader_student.ipynb`：課堂練習 notebook。
- `rag_course_presentation.html`：RAG 概念與流程投影片，可直接用瀏覽器開啟。
- `data/pdf/`：建立索引時使用的 PDF 文件。
- `pyproject.toml`、`uv.lock`：記錄需要安裝的 Python 套件與版本。
- `src/`：安裝專案時會使用，練習中不需要修改。

## 執行前準備

請先準備：

- VS Code
- VS Code 的 Python extension
- VS Code 的 Jupyter extension
- uv
- 網路連線；第一次執行 embedding 時需要下載模型

解壓縮 ZIP 後，請先開啟解壓縮完成的資料夾，不要直接在 ZIP 壓縮檔裡執行 notebook。

## 1. 安裝專案套件

用 VS Code 開啟整個 `rag_course_student` 資料夾，接著選擇：

```text
Terminal → New Terminal
```

在 VS Code 下方出現的終端機中執行：

```bash
uv sync --locked
```

這個指令會依照 `pyproject.toml` 和 `uv.lock` 建立 `.venv`，並安裝 notebook 需要的套件。第一次安裝需要一些時間。

如果顯示找不到 `uv`，請先依照課程提供的方式安裝 uv，再重新執行上面的指令。

## 2. 選擇 notebook 使用的 Python

1. 在 VS Code 開啟 `pdf_loader_student.ipynb`。
2. 按右上角的 **Select Kernel**。
3. 選擇目前專案 `.venv` 裡的 Python。

如果選單中沒有看到 `.venv`，請先確認 `uv sync --locked` 已經完成，再重新開啟 VS Code 的 kernel 選單。

## 3. 執行練習

請從 notebook 最上方開始，依序執行每一個程式 cell：

- 點選 cell 後按 `Shift + Enter`，會執行目前的 cell 並移到下一格。
- 看到 `TODO` 時，按照旁邊的說明填入內容。
- 尚未完成 TODO 時出現錯誤是預期行為；完成後重新執行該 cell。
- 不要跳過前面的 cell，後面的程式會使用前面建立的變數與資料。

Notebook 包含五個填空練習：

1. 觀察 LangChain `Document` 的文字與 metadata。
2. 調整 chunk overlap，觀察相鄰 chunks 重複保留的文字。
3. 根據 chunk 數量與向量維度判讀 embedding shape。
4. 將 cosine distance 換算成 similarity。
5. 比較不同 Top-k 設定取回的內容。

另外還有一個判斷題，用來觀察「系統找回內容」是否代表文件真的能回答問題。

## RAG 流程

Notebook 分成兩個階段：

```text
Part 1：Indexing
PDF → Pages → Chunks → Document Embeddings → ChromaDB

Part 2：Query
Question → Query Embedding → 搜尋 ChromaDB → Top-k → Context → Prompt
```

### Part 1：Indexing

Notebook 會讀取 `data/pdf/` 裡的文件，將每一頁切成 chunks，產生 embeddings，並把結果存入 `data/vector_store/`。

`data/vector_store/` 不需要事先存在，執行 notebook 時會自動建立。如果 PDF 或切割設定改變，需要重新執行 Indexing。

### Part 2：Query

Notebook 會把問題轉成 query embedding，再從 ChromaDB 找出最接近的 chunks。顯示的 similarity 代表問題與文字在向量空間中的接近程度，不代表答案一定正確。

## OpenAI API 是選用功能

PDF 載入、chunking、embedding、ChromaDB 和 retrieval 都可以在本機完成，不需要 OpenAI API key。

Notebook 最後有選用的 OpenAI Responses API 範例，預設不會執行。課堂中如果沒有要求使用，請保持：

```python
RUN_OPENAI_EXAMPLE = False
```

請勿把 API key 直接寫進 notebook，也不要把含有 API key 的 `.env` 分享給其他人。

## 常見問題

### `ModuleNotFoundError`

通常表示套件尚未安裝完成，或 notebook 選錯 Python。請確認：

1. 已在專案資料夾執行 `uv sync --locked`。
2. Notebook 的 kernel 是目前專案 `.venv` 裡的 Python。

### 找不到 `data/pdf/`

請使用 VS Code 開啟整個專案資料夾，不要只開啟單一 `.ipynb`，也不要任意移動 `data/pdf/`、`pyproject.toml` 或 notebook。

### 第一次產生 embeddings 很慢

第一次執行時需要下載 embedding 模型，所需時間會受到網路速度影響。下載完成後，之後通常會使用本機快取。

### 後面的 cell 顯示變數不存在

這通常表示前面的 cell 尚未執行，或 kernel 重新啟動過。請回到 notebook 上方，按照順序重新執行。

### 修改後出現和預期不同的舊結果

先重新執行修改過的 cell，以及所有依賴它的後續 cells。必要時可在 VS Code 的 notebook 工具列重新啟動 kernel，再從上到下執行。

## 完成前檢查

- 五個 TODO 都已完成。
- 每個練習 cell 都能正常執行。
- 能說明 Page、Chunk、Embedding、ChromaDB、Top-k、Context 各自的用途。
- 能根據檔名、頁碼與文字內容檢查檢索結果是否真的支持答案。
